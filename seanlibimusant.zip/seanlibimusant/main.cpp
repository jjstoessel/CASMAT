//
//  main.cpp
//  
//
//  Created by sean wayland on 5/9/17.
//
//

#include <stdio.h>
#include <iostream>

int main()
{
    std::cout << "Hello World!";
}
