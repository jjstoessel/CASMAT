/*
 *  libIMUSANTPriv.h
 *  libIMUSANT
 *
 *  Created by Derrick Hill on 6/06/2015.
 *
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class libIMUSANTPriv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
